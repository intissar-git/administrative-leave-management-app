
package com.helloIftekhar.springJwt.repository;

import com.helloIftekhar.springJwt.dto.EmployeesByServiceDTO;
import com.helloIftekhar.springJwt.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Integer> {

    Optional<User> findByUsername(String username);


    //add chef service codes


    List<User> findByDepartementIdAndServiceId(Integer departementId, Integer serviceId);


    List<User> findByRole(String role);

    // Trouver par matricule
    Optional<User> findByMatricule(String matricule);


    List<User> findByFirstNameContainingIgnoreCaseOrLastNameContainingIgnoreCase(String firstName, String lastName);

    List<User> findByEmail(String email);

    boolean existsByEmail(String email);

    // Trouver par département
    List<User> findByDepartementId(Integer departementId);


    // Vérifier si un username existe
    boolean existsByUsername(String username);

    @Query("SELECT u.id FROM User u WHERE u.username = :username")
    Optional<Long> findIdByUsername(@Param("username") String username);


    @Query("SELECT COUNT(u) FROM User u WHERE u.service.id = :serviceId")
    Long countByServiceId(@Param("serviceId") Long serviceId);

    // developer par  chef service
    @Query("SELECT u FROM User u WHERE u.service.id = :serviceId AND u.service.departement.id = :departementId")
    List<User> findByServiceAndDepartement(
            @Param("serviceId") Long serviceId,
            @Param("departementId") Long departementId);

//reccupere chef serviice

    // Correction dans UserRepository.java
    @Query("SELECT u FROM User u WHERE u.departement.id = :departementId AND u.role = 'CHEF_SERVICE'")
    List<User> findChefsServiceByDepartementId(@Param("departementId") Long departementId);



    //nouveauxxx

    @Query("SELECT new com.helloIftekhar.springJwt.dto.EmployeesByServiceDTO(s.id, s.nomService, COUNT(u.id)) " +
            "FROM User u " +
            "JOIN u.service s " +
            "WHERE s.departement.id = :departementId " +
            "GROUP BY s.id, s.nomService")
    List<EmployeesByServiceDTO> countEmployeesByServiceInDepartement(@Param("departementId") Long departementId);

}