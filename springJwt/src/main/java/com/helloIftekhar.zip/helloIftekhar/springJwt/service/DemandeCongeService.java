package com.helloIftekhar.springJwt.service;

import com.helloIftekhar.springJwt.dto.*;
import com.helloIftekhar.springJwt.model.DemandeConge;
import com.helloIftekhar.springJwt.model.User;
import com.helloIftekhar.springJwt.repository.DemandeCongeRepository;
import com.helloIftekhar.springJwt.repository.DepartementRepository;
import com.helloIftekhar.springJwt.repository.ServiceDepartementRepository;
import com.helloIftekhar.springJwt.repository.UserRepository;
import jakarta.persistence.Access;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@Transactional
public class DemandeCongeService {

    @Autowired
    public ServiceDepartementRepository serviceDepartementRepository;
    private final DemandeCongeRepository demandeCongeRepository;
    private final UserRepository userRepository;


    public DemandeCongeService(DemandeCongeRepository demandeCongeRepository,
                               UserRepository userRepository) {
        this.demandeCongeRepository = demandeCongeRepository;
        this.userRepository = userRepository;
    }

    public DemandeCongeResponseDTO createDemandeConge(DemandeCongeRequestDTO demandeDTO, String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));

        DemandeConge demande = new DemandeConge();
        demande.setIdEmployee(Long.valueOf(user.getId()));
        demande.setDateDebut(demandeDTO.getDateDebut());
        demande.setDateFin(demandeDTO.getDateFin());
        demande.setMotif(demandeDTO.getMotif());
        demande.setDuree(demandeDTO.getDuree());
        demande.setRemplacerPar(demandeDTO.getRemplacerPar());
        demande.setRemplacantArab(demandeDTO.getRemplacantArab());
        demande.setStatut("EN_ATTENTE"); // Set default status

        DemandeConge savedDemande = demandeCongeRepository.save(demande);
        return mapToResponseDTO(savedDemande);
    }

    public DemandeCongeResponseDTO mapToResponseDTO(DemandeConge demande) {
        // If you don't have a builder pattern in your DTO, use regular constructor/setter approach
        DemandeCongeResponseDTO responseDTO = new DemandeCongeResponseDTO();
        responseDTO.setId(demande.getId());
        responseDTO.setIdEmployee(demande.getIdEmployee());
        responseDTO.setDateCreation(demande.getDateCreation());
        responseDTO.setDateDebut(demande.getDateDebut());
        responseDTO.setDateFin(demande.getDateFin());
        responseDTO.setMotif(demande.getMotif());
        responseDTO.setStatut(demande.getStatut());
        responseDTO.setDuree(demande.getDuree());
        responseDTO.setRemplacerPar(demande.getRemplacerPar());
        responseDTO.setMotifRefus(demande.getMotifRefus());
        responseDTO.setRemplacantArab(demande.getRemplacantArab()); // Ajout de ce champ
        return responseDTO;
    }

    public List<DemandeCongeResponseDTO> getHistoriqueDemandes(String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));

        List<DemandeConge> demandes = demandeCongeRepository.findByIdEmployeeOrderByDateCreationDesc(Long.valueOf(user.getId()));

        return demandes.stream()
                .map(this::mapToResponseDTO)
                .collect(Collectors.toList());
    }

    public DemandeStatsDTO getGlobalDemandesStats() {
        long approuvees = demandeCongeRepository.countApprouvees();
        long refusees = demandeCongeRepository.countRefusees();
        long enAttente = demandeCongeRepository.countEnAttente();

        return new DemandeStatsDTO(approuvees, refusees, enAttente);
    }

    public DemandeStatsDTO getUserDemandesStats(Long userId) {
        long approuvees = demandeCongeRepository.countApprouveesByUser(userId);
        long refusees = demandeCongeRepository.countRefuseesByUser(userId);
        long enAttente = demandeCongeRepository.countEnAttenteByUser(userId);

        return new DemandeStatsDTO(approuvees, refusees, enAttente);
    }

    public List<DemandeCongeResponseDTO> getDernieresDemandes(String username, int limit) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Pageable pageable = PageRequest.of(0, limit, Sort.by("dateCreation").descending());
        Page<DemandeConge> demandesPage = demandeCongeRepository
                .findByIdEmployeeOrderByDateCreationDesc(Long.valueOf(user.getId()), pageable);

        return demandesPage.getContent().stream()
                .map(this::mapToResponseDTO)
                .collect(Collectors.toList());
    }





    // Dans DemandeCongeService.java

    // Méthode pour mettre à jour une demande
    public DemandeCongeResponseDTO updateDemandeConge(Long demandeId, DemandeCongeRequestDTO demandeDTO, String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));

        DemandeConge demande = demandeCongeRepository.findByIdAndIdEmployee(demandeId, Long.valueOf(user.getId()))
                .orElseThrow(() -> new RuntimeException("Demande not found or not owned by user"));

        // Vérifier si la demande peut être modifiée (statut EN_ATTENTE)
        if (!"EN_ATTENTE".equals(demande.getStatut())) {
            throw new RuntimeException("Seules les demandes en attente peuvent être modifiées");
        }

        demande.setDateDebut(demandeDTO.getDateDebut());
        demande.setDateFin(demandeDTO.getDateFin());
        demande.setMotif(demandeDTO.getMotif());
        demande.setDuree(demandeDTO.getDuree());
        demande.setRemplacerPar(demandeDTO.getRemplacerPar());
        demande.setRemplacantArab(demandeDTO.getRemplacantArab());

        DemandeConge updatedDemande = demandeCongeRepository.save(demande);
        return mapToResponseDTO(updatedDemande);
    }

    // Méthode pour supprimer une demande
    public void deleteDemandeConge(Long demandeId, String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));

        DemandeConge demande = demandeCongeRepository.findByIdAndIdEmployee(demandeId, Long.valueOf(user.getId()))
                .orElseThrow(() -> new RuntimeException("Demande not found or not owned by user"));

        // Vérifier si la demande peut être supprimée (statut EN_ATTENTE)
        if (!"EN_ATTENTE".equals(demande.getStatut())) {
            throw new RuntimeException("Seules les demandes en attente peuvent être supprimées");
        }

        demandeCongeRepository.delete(demande);
    }

    public List<ServiceDepartementDTO> getAllServicesByDepartement(Long departementId) {
        return serviceDepartementRepository.findByDepartementId(departementId)
                .stream()
                .map(ServiceDepartementMapper::toDto)
                .collect(Collectors.toList());
    }
    public List<DemandeCongeResponseDTO> getAllDemandes() {
        List<DemandeConge> demandes = demandeCongeRepository.findAll();
        return demandes.stream()
                .map(this::mapToResponseDTO)
                .collect(Collectors.toList());
    }

    public List<DemandeCongeResponseDTO> getAllDemandesWithEmployeeInfo() {
        return demandeCongeRepository.findAllWithEmployeeInfo();
    }


    // Dans DemandeCongeService.java
    @Transactional
    public void updateStatutDemande(Long id, String statut, String motifRefus) {
        // Si le statut est "REFUSE" et qu'il n'y a pas de motif de refus
        if ("REFUSE".equals(statut) && (motifRefus == null || motifRefus.isEmpty())) {
            throw new RuntimeException("Un motif de refus est obligatoire pour rejeter une demande");
        }

        // Si le statut n'est pas "REFUSE", on ne garde pas le motif de refus
        String finalMotifRefus = "REFUSE".equals(statut) ? motifRefus : null;

        demandeCongeRepository.updateStatutAndMotifRefus(id, statut, finalMotifRefus);
    }











// ========== NOUVELLES FONCTIONNALITÉS ==========

    //fonctionnalites nouveaux

    public DemandeStatsDTO getStatsDemandesChefsByDepartement(Long departementId) {
        // 1. Vérification de l'ID du département
        if (departementId == null) {
            throw new IllegalArgumentException("L'ID du département ne peut pas être null");
        }

        // 2. Récupération des chefs de service avec vérification
        List<User> chefsService = userRepository.findChefsServiceByDepartementId(departementId);
        if (chefsService.isEmpty()) {
            System.out.println("[INFO] Aucun chef de service trouvé pour le département " + departementId);
            return new DemandeStatsDTO(0L, 0L, 0L);
        }

        // 3. Extraction des IDs des employés
        List<Long> chefsIds = chefsService.stream()
                .map(user -> Long.valueOf(user.getId()))
                .collect(Collectors.toList());

        // Debug: Afficher la liste des chefs de service
        System.out.println("[DEBUG] Liste des chefs de service:");
        chefsService.forEach(chef -> System.out.println(
                "ID: " + chef.getId() +
                        ", Nom: " + chef.getFirstName() + " " + chef.getLastName()
        ));

        // 4. Récupération de toutes les demandes
        List<DemandeConge> allDemandes = (List<DemandeConge>) demandeCongeRepository.findByIdEmployeeIn(chefsIds);

        // 5. Comptage manuel avec vérification des statuts
        long approuvees = 0L;
        long enAttente = 0L;
        long refusees = 0L;

        System.out.println("[DEBUG] Détail des demandes:");
        for (DemandeConge demande : allDemandes) {
            System.out.println(
                    "ID: " + demande.getId() +
                            ", Statut: " + demande.getStatut() +
                            ", Employé: " + demande.getIdEmployee() +
                            ", Date: " + demande.getDateCreation()
            );

            // Vérification case-sensitive des statuts
            if ("APPROUVE".equalsIgnoreCase(demande.getStatut())) {
                approuvees++;
            } else if ("EN_ATTENTE".equalsIgnoreCase(demande.getStatut())
                    || "EN ATTENTE".equalsIgnoreCase(demande.getStatut())) {
                enAttente++;
            } else if ("REFUSE".equalsIgnoreCase(demande.getStatut())
                    || "REFUSÉ".equalsIgnoreCase(demande.getStatut())) {
                refusees++;
            }
        }

        // 6. Affichage des totaux
        System.out.println("[DEBUG] Totaux calculés - " +
                "Approuvées: " + approuvees +
                ", En attente: " + enAttente +
                ", Refusées: " + refusees);

        return new DemandeStatsDTO(approuvees, refusees, enAttente);
    }













    // Dans DemandeCongeService.java

    public long countByEmployeeIds(List<Long> employeeIds) {
        if (employeeIds.isEmpty()) return 0;
        return demandeCongeRepository.countByIdEmployeeIn(employeeIds);
    }

    public long countByEmployeeIdsAndStatus(List<Long> employeeIds, String status) {
        if (employeeIds.isEmpty()) return 0;
        return demandeCongeRepository.countByIdEmployeeInAndStatut(employeeIds, status);
    }




    public List<DemandeCongeResponseDTO> findRecentByEmployeeIds(List<Long> employeeIds, int limit) {
        if (employeeIds.isEmpty()) return Collections.emptyList();

        // Modification importante ici - Ajout du tri explicite
        Pageable pageable = PageRequest.of(
                0, // première page
                limit, // nombre d'éléments
                Sort.by(Sort.Direction.DESC, "dateCreation") // tri explicite par date décroissante
        );

        return demandeCongeRepository.findByIdEmployeeIn(employeeIds, pageable)
                .getContent()
                .stream()
                .map(this::mapToResponseDTO)
                .collect(Collectors.toList());




    }

}